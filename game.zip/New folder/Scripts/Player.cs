﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
  //serializefield = acces a private variable in unity editor 
    [SerializeField]
    private float _speed ;
    [SerializeField]
    private GameObject _laserPrefab;
    [SerializeField]
    private float _fireRate = 0.5f;
    private float _canFire = -1f;
    [SerializeField]
    private int _lives =3;
    private Spawn_Manager _spawnManager;
    [SerializeField]
    private bool _laserpower = false;
    [SerializeField]
    private GameObject _laserPrefab1;
    [SerializeField]
    private bool _pspeed = false;
    private UI_Manager uimanager;
    private bool _isShieldActive = false;
    [SerializeField]
    private GameObject ShieldVisualizer;
    [SerializeField]
    private int score = 0;
    // Start is called before the first frame update
    void Start()
    {

        transform.position = new Vector3(0, 0, 0);
        _spawnManager = GameObject.Find("Spawn_Manager").GetComponent<Spawn_Manager>();



        if (_spawnManager == null)
        {
            Debug.LogError("The Spawn Manager is null");
        }

        uimanager = GameObject.Find("Canvas").GetComponent<UI_Manager>();

    }

    // Update is called once per frame
    void Update()
    {
        CalculateMovement();

        if (Input.GetKeyDown(KeyCode.Space) && Time.time > _canFire)
        {
            ShootLaser();
        }

    }

    void ShootLaser()
    {
        _canFire = Time.time + _fireRate;
        if (_laserpower == true)
        {
            Instantiate(_laserPrefab1, transform.position, Quaternion.identity);
        }

        else
        {
            Instantiate(_laserPrefab, transform.position + new Vector3(0, 1.05f, 0), Quaternion.identity);

        }
    }

    void CalculateMovement()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        Vector3 direction = new Vector3(horizontalInput, verticalInput, 0);

        if(_pspeed == false)
        {
            transform.Translate(direction * _speed * Time.deltaTime);
        }
        else { 
            transform.Translate(direction * _speed * 1.5f * Time.deltaTime); 
        }


        transform.position = new Vector3(transform.position.x, Mathf.Clamp(transform.position.y, -3.8f, 0), transform.position.z);

        if (transform.position.x >= 11)
        {
            transform.position = new Vector3(-11, transform.position.y, transform.position.z);
        }

        else if (transform.position.x <= -11)
        {
            transform.position = new Vector3(11, transform.position.y, transform.position.z);

        }
    }

    public void AdScore()
    {
        score = score + 10;
        uimanager.UpdateScore(score);
    }

    public void Damage()
    {
        if (_isShieldActive == true)
        {
            _isShieldActive = false;
            ShieldVisualizer.SetActive(false);
            return;
        }

        _lives -= 1;

        if (_lives <1)
        {
            _spawnManager.OnPlayerDeath();
            Destroy(this.gameObject);

        }
    }

    public void TripleShotActive()
    {
        _laserpower = true;
        StartCoroutine(TripleShotPowerDownRoutine());
    }

    IEnumerator TripleShotPowerDownRoutine()
    {
        yield return new WaitForSeconds(5.0f);
        _laserpower = false;
    }

    public void SpeedActive()
    {
        _pspeed = true;
        StartCoroutine(SpeedPowerDownRoutine());
    }

    IEnumerator SpeedPowerDownRoutine()
    {
        yield return new WaitForSeconds(5.0f);
        _pspeed = false;
    }

    public void ShieldActive()
    {
        _isShieldActive = true;
        ShieldVisualizer.SetActive(true);
    }

   
    
}
