﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField]
    private float _speed = 4.0f;
    private int score;
    private Player _p;
    private
    // Start is called before the first frame update
    void Start()
    {

        _p = GameObject.Find("Player").GetComponent<Player>();

        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.down * Time.deltaTime * _speed);

        if(transform.position.y < -5f)
        {
            float randomX = Random.Range(-9f, 9f);
            transform.position = new Vector3(randomX, 7 , 0);
        }



    }

  

    private void OnTriggerEnter2D(Collider2D other)
    {

        

        if (other.tag == "Player")
        {
            Player player = other.transform.GetComponent<Player>();
            if (player !=null)
            {
                player.Damage();
            }
            Destroy(this.gameObject);
        }


        if (other.tag == "Laser")
        {
            Destroy(other.gameObject);
            if (_p != null)
            {
                _p.AdScore();
            }

            Destroy(this.gameObject);
        }
    }

   

}
