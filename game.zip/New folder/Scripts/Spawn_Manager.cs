﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn_Manager : MonoBehaviour
{
    [SerializeField]
    private GameObject _enemyPrefab;
    [SerializeField]
    private GameObject _enemyContainer;
    [SerializeField]
    private GameObject[] powerups;

    // Start is called before the first frame update

    private bool _stopSpawning = false;

    private Enemy enemy;

    void Start()
    {
        StartCoroutine(SpawnEnemyRoutine());
        StartCoroutine(SpawnPowerRoutine());
        
    }

    // Update is called once per frame
    void Update()
    {
        
        
    }

   
    public void OnPlayerDeath()
    {
        _stopSpawning = true;
       
    }

    IEnumerator SpawnEnemyRoutine()
    {
        while(_stopSpawning == false)
        {
            yield return new WaitForSeconds(10.0f);
            Vector3 PosToSpawn = new Vector3(Random.Range(-9f, 9f), 7, 0);
            GameObject newenemy = Instantiate(_enemyPrefab, PosToSpawn, Quaternion.identity);
            newenemy.transform.parent = _enemyContainer.transform;
            yield return new WaitForSeconds(10.0f);
        }

        if (_stopSpawning == true)
        {
            Destroy(_enemyContainer);
        }


    }

    IEnumerator SpawnPowerRoutine()
    {
        while (_stopSpawning == false)
        {

            Vector3 PosToSpawn1 = new Vector3(Random.Range(-9f, 9f), 7, 0);
            int randomPowerup = Random.Range(0, 3);
            GameObject newpow = Instantiate(powerups[randomPowerup], PosToSpawn1, Quaternion.identity);
            newpow.transform.parent = _enemyContainer.transform;
            yield return new WaitForSeconds(Random.Range(1.0f,15.0f));
        }

        

    }

}
